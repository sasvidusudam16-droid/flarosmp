"use client";

import "@/styles/landing.css";
import { useEffect, useState } from "react";
import { Icon } from "@/components/Icon";
import { Navigation } from "@/components/Navigation";
import { FeaturesSection } from "@/components/FeaturesSection";
import { RulesSection } from "@/components/RulesSection";
import { StoreSection } from "@/components/StoreSection";
import { FaqSection } from "@/components/FaqSection";
import { PartnersSection } from "@/components/PartnersSection";
import { SmoothScroll } from "@/components/SmoothScroll";
import {
  SERVER_NAME,
  SERVER_IP,
  DISCORD_URL,
  STORE_URL,
  VOTE_URL,
  SOCIALS,
} from "@/data/site";

function SocialIcon({ name }: { name: string }) {
  if (name === "tiktok") return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
      <path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-2.88 2.5 2.89 2.89 0 0 1-2.89-2.89 2.89 2.89 0 0 1 2.89-2.89c.28 0 .54.04.79.1V9.01a6.27 6.27 0 0 0-.79-.05 6.34 6.34 0 0 0-6.34 6.34 6.34 6.34 0 0 0 6.34 6.34 6.34 6.34 0 0 0 6.33-6.34V8.66a8.18 8.18 0 0 0 4.78 1.52V6.72a4.85 4.85 0 0 1-1.01-.03z"/>
    </svg>
  );
  if (name === "youtube") return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
      <path d="M23.495 6.205a3.007 3.007 0 0 0-2.088-2.088c-1.87-.501-9.396-.501-9.396-.501s-7.507-.01-9.396.501A3.007 3.007 0 0 0 .527 6.205a31.247 31.247 0 0 0-.522 5.805 31.247 31.247 0 0 0 .522 5.783 3.007 3.007 0 0 0 2.088 2.088c1.868.502 9.396.502 9.396.502s7.506 0 9.396-.502a3.007 3.007 0 0 0 2.088-2.088 31.247 31.247 0 0 0 .5-5.783 31.247 31.247 0 0 0-.5-5.805zM9.609 15.601V8.408l6.264 3.602z"/>
    </svg>
  );
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
      <path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057c.002.022.015.043.033.055a19.944 19.944 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028 13.99 13.99 0 0 0 1.226-1.994.076.076 0 0 0-.041-.106 13.154 13.154 0 0 1-1.872-.892.077.077 0 0 1-.008-.127 10.22 10.22 0 0 0 .372-.292.074.074 0 0 1 .077-.01c3.928 1.793 8.18 1.793 12.062 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127 12.299 12.299 0 0 1-1.873.892.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.03z"/>
    </svg>
  );
}

export default function Home() {
  const [online, setOnline] = useState<number | null>(null);
  const [copied, setCopied] = useState(false);
  const [open, setOpen] = useState<number | null>(0);
  const [menu, setMenu] = useState(false);
  const [year, setYear] = useState(2026);

  useEffect(() => {
    setYear(new Date().getFullYear());
  }, []);

  useEffect(() => {
    fetch(`https://api.mcsrvstat.us/3/${SERVER_IP}`)
      .then((r) => r.json())
      .then((d) => setOnline(d?.players?.online ?? 0))
      .catch(() => setOnline(null));
  }, []);

  useEffect(() => {
    const els = document.querySelectorAll<HTMLElement>(
      ".title, .sub, .card, .rule, .faq-item, .cta, .note, .rank-card, .shard-card"
    );
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) {
            e.target.classList.add("in");
            io.unobserve(e.target);
          }
        });
      },
      { threshold: 0.1 }
    );
    // stagger siblings in the same grid independently
    const groups = new Map<Element, number>();
    els.forEach((el) => {
      const parent = el.parentElement ?? document.body;
      const idx = (groups.get(parent) ?? -1) + 1;
      groups.set(parent, idx);
      el.classList.add("reveal");
      el.style.setProperty("--d", `${idx * 80}ms`);
      io.observe(el);
    });
    return () => io.disconnect();
  }, []);

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(SERVER_IP);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {}
  };

  return (
    <>
      <SmoothScroll />
      <Navigation menu={menu} setMenu={setMenu} />

      <section id="home" className="hero">
        {/* Floating geometric shapes — fire world ambient motion */}
        <div className="hero-shapes" aria-hidden="true">
          <div className="hs hs-diamond hs-1" />
          <div className="hs hs-diamond hs-2" />
          <div className="hs hs-diamond hs-3" />
          <div className="hs hs-hex hs-4" />
          <div className="hs hs-hex hs-5" />
          <div className="hs hs-ring hs-6" />
          <div className="hs hs-ring hs-7" />
          <div className="hs hs-cross hs-8" />
          <div className="hs hs-cross hs-9" />
          <div className="ember e1" /><div className="ember e2" /><div className="ember e3" />
          <div className="ember e4" /><div className="ember e5" /><div className="ember e6" />
        </div>
        <div className="hero2">
          <h1 className="hero-title">
            <span className="hw hw-flaro">FLARO</span>
            <span className="hw hw-smp">SMP</span>
          </h1>

          <span className="pill">
            <b className="pill-no">#1</b>
            Minecraft SMP Server
          </span>

          <img className="logo-main" src="/logo.png" alt={`${SERVER_NAME} logo`} />

          <div className="side side-left">
            <h3>Choose your path</h3>
            <div className="side-line"><i /></div>
            <p>Survive, build and trade your way across our custom world.</p>
          </div>

          <div className="side side-right">
            <h3>Enjoy the moment</h3>
            <div className="side-line rev"><i /></div>
            <p>We handle the rest. Lag-free, fair and active 24/7.</p>
          </div>

          <div className="hero2-bottom">
            <div className="info-card">
              <div className="info-icon"><Icon name="chat" size={28} /></div>
              <div>
                <b>Join our community</b>
                <span>Chat, trade &amp; get support</span>
                <a href={DISCORD_URL} target="_blank" rel="noreferrer" className="mini-link">
                  Open Discord <Icon name="arrow" size={14} />
                </a>
              </div>
            </div>

            <div className="center-cta">
              <p className="tagline">
                Premium survival made for those who crave more than just vanilla.
              </p>
              <div className="btn-row">
                <button onClick={copy} className="btn btn-fire big">
                  {copied ? (
                    <><Icon name="check" size={18} /> Copied!</>
                  ) : (
                    <><Icon name="copy" size={18} /> Copy IP: {SERVER_IP}</>
                  )}
                </button>
                <a href={STORE_URL} target="_blank" rel="noreferrer" className="btn btn-outline big">
                  Visit Store
                </a>
              </div>
            </div>

            <div className="stat-card">
              <div className="stat-big">
                {online === null ? "—" : online}+
              </div>
              <span>Players online now</span>
              <div className="avatars">
                <img src="https://mc-heads.net/avatar/Steve/40" alt="" />
                <img src="https://mc-heads.net/avatar/Alex/40" alt="" />
                <img src="https://mc-heads.net/avatar/Notch/40" alt="" />
                <em>24/7 · 1.21+</em>
              </div>
            </div>
          </div>
        </div>
      </section>

      <PartnersSection />
      <FeaturesSection />
      <RulesSection />
      <StoreSection />
      <FaqSection open={open} setOpen={setOpen} />

      <section id="vote" className="section">
        <div className="container">
          <div className="cta">
            <h2>Ready to join the flames?</h2>
            <p>Vote for us daily to earn rewards and help the server grow.</p>
            <div className="hero-btns center">
              <a href={VOTE_URL} target="_blank" rel="noreferrer" className="btn btn-dark">Vote Now</a>
              <a href={DISCORD_URL} target="_blank" rel="noreferrer" className="btn btn-discord">Join Discord</a>
            </div>
          </div>
        </div>
      </section>

      <footer className="footer">
        <div className="container foot-inner">
          <div className="brand">
            <img src="/logo.png" alt={SERVER_NAME} />
            <span>{SERVER_NAME}</span>
          </div>
          <div className="foot-socials">
            {SOCIALS.map((s) => (
              <a key={s.label} href={s.href} target="_blank" rel="noreferrer" className="foot-social-link" aria-label={s.label}>
                <SocialIcon name={s.icon} />
              </a>
            ))}
          </div>
          <p>© {year} {SERVER_NAME}. Not affiliated with Mojang or Microsoft.</p>
        </div>
      </footer>

      {/* Floating social buttons — right side */}
      <div className="fab-stack">
        <a href={DISCORD_URL} target="_blank" rel="noreferrer" className="fab-btn fab-btn-discord" aria-label="Discord">
          <svg width="22" height="17" viewBox="0 0 127.14 96.36" fill="currentColor">
            <path d="M107.7,8.07A105.15,105.15,0,0,0,81.47,0a72.06,72.06,0,0,0-3.36,6.83A97.68,97.68,0,0,0,49,6.83,72.37,72.37,0,0,0,45.64,0,105.89,105.89,0,0,0,19.39,8.09C2.79,32.65-1.71,56.6.54,80.21h0A105.73,105.73,0,0,0,32.71,96.36,77.7,77.7,0,0,0,39.6,85.25a68.42,68.42,0,0,1-10.85-5.18c.91-.66,1.8-1.34,2.66-2a75.57,75.57,0,0,0,64.32,0c.87.71,1.76,1.39,2.66,2a68.68,68.68,0,0,1-10.87,5.19,77,77,0,0,0,6.89,11.1A105.25,105.25,0,0,0,126.6,80.22h0C129.24,52.84,122.09,29.11,107.7,8.07ZM42.45,65.69C36.18,65.69,31,60,31,53s5-12.74,11.43-12.74S54,46,53.89,53,48.84,65.69,42.45,65.69Zm42.24,0C78.41,65.69,73.25,60,73.25,53s5-12.74,11.44-12.74S96.23,46,96.12,53,91.08,65.69,84.69,65.69Z"/>
          </svg>
        </a>
        <a href="https://youtube.com/@mrflaroo" target="_blank" rel="noreferrer" className="fab-btn fab-btn-yt" aria-label="YouTube">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="currentColor">
            <path d="M23.495 6.205a3.007 3.007 0 0 0-2.088-2.088c-1.87-.501-9.396-.501-9.396-.501s-7.507-.01-9.396.501A3.007 3.007 0 0 0 .527 6.205a31.247 31.247 0 0 0-.522 5.805 31.247 31.247 0 0 0 .522 5.783 3.007 3.007 0 0 0 2.088 2.088c1.868.502 9.396.502 9.396.502s7.506 0 9.396-.502a3.007 3.007 0 0 0 2.088-2.088 31.247 31.247 0 0 0 .5-5.783 31.247 31.247 0 0 0-.5-5.805zM9.609 15.601V8.408l6.264 3.602z"/>
          </svg>
        </a>
        <a href="https://tiktok.com/@mrflaro" target="_blank" rel="noreferrer" className="fab-btn fab-btn-tiktok" aria-label="TikTok">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
            <path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-2.88 2.5 2.89 2.89 0 0 1-2.89-2.89 2.89 2.89 0 0 1 2.89-2.89c.28 0 .54.04.79.1V9.01a6.27 6.27 0 0 0-.79-.05 6.34 6.34 0 0 0-6.34 6.34 6.34 6.34 0 0 0 6.34 6.34 6.34 6.34 0 0 0 6.33-6.34V8.66a8.18 8.18 0 0 0 4.78 1.52V6.72a4.85 4.85 0 0 1-1.01-.03z"/>
          </svg>
        </a>
      </div>
    </>
  );
}