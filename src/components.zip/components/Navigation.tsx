"use client";

import { DISCORD_URL, NAV, SERVER_NAME } from "@/data/site";
import { Icon } from "@/components/Icon";

export function Navigation({ menu, setMenu }: { menu: boolean; setMenu: (value: boolean) => void }) {
  return (
    <>
      {/* Backdrop */}
      {menu && (
        <div
          className="nav-backdrop"
          onClick={() => setMenu(false)}
          aria-hidden="true"
        />
      )}

      <header className="nav">
        <div className="nav-bar">
          <a href="#home" className="brand" onClick={() => setMenu(false)}>
            <img
              className="brand-icon"
              src="/logo.png"
              alt={SERVER_NAME}
            />
            <span className="brand-text">{SERVER_NAME}</span>
          </a>

          <nav className={`links${menu ? " show" : ""}`} aria-label="Main navigation">
            {NAV.map((n) =>
              n.children ? (
                <div className="dd" key={n.label}>
                  <button type="button" className="dd-btn">
                    {n.label}
                    <Icon name="chevron" size={14} />
                  </button>
                  <div className="dd-menu">
                    {n.children.map((c) => (
                      <a
                        key={c.label}
                        href={c.href}
                        target={c.external ? "_blank" : undefined}
                        rel={c.external ? "noreferrer" : undefined}
                        onClick={() => setMenu(false)}
                        className="dd-item"
                      >
                        <span className="dd-ico">
                          <Icon name={c.icon} size={18} />
                        </span>
                        <span className="dd-txt">
                          <b>{c.label}</b>
                          <small>{c.desc}</small>
                        </span>
                      </a>
                    ))}
                  </div>
                </div>
              ) : (
                <a key={n.label} href={n.href} onClick={() => setMenu(false)}>
                  {n.label}
                </a>
              )
            )}
          </nav>

          <div className="nav-right">
            <a href={DISCORD_URL} target="_blank" rel="noreferrer" className="btn-discord-nav" aria-label="Join our Discord">
              {/* Official Discord Clyde icon */}
              <svg width="22" height="17" viewBox="0 0 127.14 96.36" fill="currentColor" aria-hidden="true">
                <path d="M107.7,8.07A105.15,105.15,0,0,0,81.47,0a72.06,72.06,0,0,0-3.36,6.83A97.68,97.68,0,0,0,49,6.83,72.37,72.37,0,0,0,45.64,0,105.89,105.89,0,0,0,19.39,8.09C2.79,32.65-1.71,56.6.54,80.21h0A105.73,105.73,0,0,0,32.71,96.36,77.7,77.7,0,0,0,39.6,85.25a68.42,68.42,0,0,1-10.85-5.18c.91-.66,1.8-1.34,2.66-2a75.57,75.57,0,0,0,64.32,0c.87.71,1.76,1.39,2.66,2a68.68,68.68,0,0,1-10.87,5.19,77,77,0,0,0,6.89,11.1A105.25,105.25,0,0,0,126.6,80.22h0C129.24,52.84,122.09,29.11,107.7,8.07ZM42.45,65.69C36.18,65.69,31,60,31,53s5-12.74,11.43-12.74S54,46,53.89,53,48.84,65.69,42.45,65.69Zm42.24,0C78.41,65.69,73.25,60,73.25,53s5-12.74,11.44-12.74S96.23,46,96.12,53,91.08,65.69,84.69,65.69Z"/>
              </svg>
            </a>

            <button
              className="burger"
              onClick={() => setMenu(!menu)}
              aria-label={menu ? "Close menu" : "Open menu"}
              aria-expanded={menu}
            >
              {menu ? (
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
                  <line x1="18" y1="6" x2="6" y2="18" />
                  <line x1="6" y1="6" x2="18" y2="18" />
                </svg>
              ) : (
                <Icon name="menu" size={26} />
              )}
            </button>
          </div>
        </div>
      </header>
    </>
  );
}
